
<?php $__env->startSection("content"); ?>



    <!-- bradcrumb -->
    <section class="bradcrumb-area page-background">
      <div class="container">
        <div class="row">
          <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="bradcrumb-box text-center">
              <h1>Wishlist</h1>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- bradcrumb -->
    <!-- wishlist Product -->
    <section class="wishlist-product-area page-paddings">
      <div class="container">
        <div class="row">
          <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="whislist-pro-box">
              <div class="theme-table">
                <table>
                  <thead>
                  <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Stock Status</th>
                    <th>View Details</th>
                    <th>Remove</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td>
                        <div class="cart-pro-box">
                          <div class="cart-pro-img"><img src="<?php echo e(asset($product->photo)); ?>" alt=""></div>
                          <div class="cart-pro-content">
                            <h3 class="theme-title"><?php echo e($product->name); ?></h3>
                            <div class="product-ratting">
                              <i class="fas fa-star ratting-active"></i><i class="fas fa-star ratting-active"></i><i class="fas fa-star ratting-active"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td><span class="cart-subtotal">$<?php echo e($product->sale); ?></span></td>
                      <td class="pro-stock <?php echo e($product->quantity > 1 ? 'in-stock' : 'out-stock'); ?>"><?php echo e($product->quantity > 1 ? 'In Stock' : 'Out of Stock'); ?></td>
                      <td><a href="<?php echo e(url($product->pagelink())); ?>" class="theme-btn">View Details</a></td>
                      <td><button class="cart-tras-btn slide-remove-btn" data-id="<?php echo e($product->id); ?>"><i class="fas fa-trash-alt"></i></button></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan="5"><h2>No products found.</h2></td>
                    </tr>
                  <?php endif; ?>

                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- wishlist Product -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\petstore\resources\views/client/pages/wishlist.blade.php ENDPATH**/ ?>