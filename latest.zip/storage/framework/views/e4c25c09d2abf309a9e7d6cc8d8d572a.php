<?php $__env->startSection('main-section'); ?>
    <?php $__env->startPush('title'); ?>
        <title>Add Product - Kimbowny</title>
    <?php $__env->stopPush(); ?>
    <style>
        /* Custom Styles */
        .form-group .row>div {
            margin-bottom: 10px;
            margin-top: 10px;
            /* Adds space between rows */
        }

        #colorSizeWrapper,
        #flavorWrapper,
        #flavorWeightWrapper,
        #flavorPiecesWrapper,
        #shapeSizeWrapper,
        #piecesWrapper {
            background-color: #f7f7f7;
            /* Light grey background */

            border-radius: 5px;
            /* Rounded corners */
            margin-top: 10px;
            /* Space between button and wrapper */
        }

        .btn-info {
            width: 100%;
            /* Make buttons take the full width of the column */
            margin-bottom: 5px;
            /* Space below buttons */
        }


        .btncustom {
            border-radius: 25px;

        }
    </style>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><i class="fas fa-box"></i>&nbsp;Add Product</h1>
                    </div>


                    <div class="col-sm-6">
                        <div class="d-flex justify-content-between align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                                <li class="breadcrumb-item active">Product</li>
                            </ol>
                            <a href="<?php echo e(route('admin.product.show')); ?>" class="btn btn-submit">View</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header"
                                style="background: linear-gradient(to right, rgba(0, 123, 255, 0.7), rgba(0, 86, 179, 0.7)); color: rgba(255, 255, 255, 0.9); font-size: 1.8em; text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.8);">
                                <h3 class="card-title" style="font-size: 0.8em;">Add Product</h3>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('admin.product.store')); ?>" method="post"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">

                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text icon"><i
                                                                class="fas fa-pen"></i></span>
                                                    </div>
                                                    <input type="text" name="productname" required
                                                        class="form-control <?php $__errorArgs = ['productname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        placeholder="Product Name..." value="<?php echo e(old('productname')); ?>">
                                                </div>
                                                <?php $__errorArgs = ['productname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">

                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text icon"><i class="fas fa-cubes"></i>
                                                        </span>
                                                    </div>
                                                    <input type="number" name="productquantity" required
                                                        class="form-control <?php $__errorArgs = ['productquantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        placeholder="Product Quantity..."
                                                        value="<?php echo e(old('productquantity')); ?>">
                                                </div>
                                                <?php $__errorArgs = ['productquantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text icon">
                                                            <i class="fas fa-layer-group"></i>
                                                            <!-- Changed icon to 'fa-tags' for category context -->
                                                        </span>
                                                    </div>
                                                    <select class="form-control" id="categorySelect" name="category"
                                                        required>
                                                        <option value="" disabled selected>Select Category...</option>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text icon">
                                                            <i class="fas fa-paw"></i>
                                                            <!-- Changed icon to 'fa-paw' for pet context -->
                                                        </span>
                                                    </div>
                                                    <select class="form-control" id="petSelect" name="pet" required>
                                                        <option value="" disabled selected>Select Pet...</option>
                                                        <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($pet->id); ?>"><?php echo e($pet->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['pet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                        </div>


                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">

                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text icon"><i
                                                                class="fas fa-percentage"></i></span>
                                                    </div>
                                                    <input type="number" class="form-control" id="productdiscount"
                                                        name="productdiscount" required placeholder="Enter Discount...">
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['productdiscount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text icon">
                                                            <i class="fas fa-star"></i>
                                                            <!-- Changed icon to 'fa-tags' for category context -->
                                                        </span>
                                                    </div>
                                                    <select class="form-control" id="featureSelect" name="feature" required>
                                                        <option value="" disabled selected>Select Feature...
                                                        </option>

                                                        <option value="1">Show</option>
                                                        <option value="0">Hide</option>

                                                    </select>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['feature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>


                                    </div>
                                    <div class="form-group">

                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text icon"><i class="fas fa-image"></i></span>
                                            </div>
                                            <div class="custom-file">
                                                <input type="file"
                                                    class="form-control <?php $__errorArgs = ['productimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="image" name="productimage[]" multiple>
                                                <label class="custom-file-label" for="image"
                                                    style="color: #999999e8;">Choose Product Image...</label>
                                            </div>
                                        </div>
                                        <?php $__errorArgs = ['productimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!-- Place this before the product description in your form -->
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-2">
                                                <button type="button" id="addColorSize"
                                                    class="btn btn-info btncustom">Add
                                                    Color/Size</button>

                                            </div>
                                            <div class="col-md-2">
                                                <button type="button" id="addFlavor" class="btn btn-info btncustom">Add
                                                    Flavor</button>

                                            </div>
                                            <div class="col-md-2">
                                                <button type="button" id="addFlavorWeight"
                                                    class="btn btn-info btncustom">Add
                                                    Flavor/Weight</button>

                                            </div>
                                            <div class="col-md-2">
                                                <button type="button" id="addFlavorPieces"
                                                    class="btn btn-info btncustom">Add
                                                    Flavor/Pieces</button>

                                            </div>
                                            <div class="col-md-2">
                                                <button type="button" id="addShapeSize"
                                                    class="btn btn-info btncustom">Add
                                                    Shape/Size</button>

                                            </div>
                                            <div class="col-md-2">
                                                <button type="button" id="addPieces" class="btn btn-info btncustom">Add
                                                    Pieces</button>

                                            </div>
                                        </div>
                                        <div id="colorSizeWrapper"></div>
                                        <div id="flavorWrapper"></div>
                                        <div id="piecesWrapper"></div>
                                        <div id="shapeSizeWrapper"></div>
                                        <div id="flavorPiecesWrapper"></div>
                                        <div id="flavorWeightWrapper"></div>
                                        <!-- Container for dynamic color and size inputs -->
                                    </div>


                                    <div class="form-group">

                                        <div class="input-group">

                                            <textarea id="description" name="productdescription"
                                                class="form-control <?php $__errorArgs = ['productdescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                placeholder="Write your product description here..."><?php echo e(old('productdescription')); ?></textarea>
                                        </div>
                                        <?php $__errorArgs = ['productdescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!-- Dynamic fields for color, size, Price price, and sale price selection -->
                                    <div class="form-group" hidden>
                                        <label for="dynamicColor">Color</label>
                                        <input type="text" id="dynamicColor" name="color[]" class="form-control">
                                    </div>

                                    <div class="form-group" hidden>
                                        <label for="dynamicSize">Size</label>
                                        <input type="text" id="dynamicSize" name="size[]" class="form-control">
                                    </div>
                                    <div class="form-group" hidden>
                                        <label for="dynamicWeight">Weight</label>
                                        <input type="text" id="dynamicWeight" name="weight[]" class="form-control">
                                    </div>
                                    <div class="form-group" hidden>
                                        <label for="dynamicFlavor">Flavor</label>
                                        <input type="text" id="dynamicFlavor" name="flavor[]" class="form-control">
                                    </div>
                                    <div class="form-group" hidden>
                                        <label for="dynamicShape">Shape</label>
                                        <input type="text" id="dynamicShape" name="shape[]" class="form-control">
                                    </div>
                                    <div class="form-group" hidden>
                                        <label for="dynamicPieces">Pieces</label>
                                        <input type="text" id="dynamicPieces" name="pieces[]" class="form-control">
                                    </div>

                                    <div class="form-group" hidden>
                                        <label for="purchasePrice">Purchase Price</label>
                                        <input type="number" id="purchasePrice" name="purchase[]" class="form-control">
                                    </div>

                                    <div class="form-group" hidden>
                                        <label for="salePrice">Sale Price</label>
                                        <input type="number" id="salePrice" name="sale[]" class="form-control">
                                    </div>
                                    <div class="card-footer" style="text-align: right">
                                        <button type="submit" class="btn btn-submit">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            let wrapper = $("#colorSizeWrapper");
            let addColorSizeButton = $("#addColorSize");

            let flavorwrapper = $("#flavorWrapper");
            let addFlavorButton = $("#addFlavor");

            let flavorWeightwrapper = $("#flavorWeightWrapper");
            let addFlavorWeightButton = $("#addFlavorWeight");

            let piecesWrapper = $("#piecesWrapper");
            let addPiecesButton = $("#addPieces");

            let flavorPiecesWrapper = $("#flavorPiecesWrapper");
            let addFlavorPiecesButton = $("#addFlavorPieces");

            let shapeSizeWrapper = $("#shapeSizeWrapper");
            let addShapeSizeButton = $("#addShapeSize");

            $(addColorSizeButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#flavorWeightwrapper").empty();
                $("#piecesWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#shapeSizeWrapper").empty();

                $(wrapper).append(`
                  <div class="row align-items-end">
                      <div class="col">
                          <div class="form-group">
                              <label>Color</label>
                              <select class="form-control form-control-custom color-select" name="color[]">
                                  <option value="" disabled selected>Select Color</option>
                                  <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($colors->id); ?>"><?php echo e($colors->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Size</label>
                              <select class="form-control form-control-custom size-select" name="size[]">
                                  <option value="" disabled selected>Select Size</option>
                                  <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($sizes->id); ?>"><?php echo e($sizes->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicColorInput = $("#dynamicColor");
                // Get the last added color-select
                lastColorSelect.on("change", function() {
                    let selectedColor = $(this).find("option:selected").val();
                    dynamicColorInput.val(selectedColor);
                });

                let dynamicSizeInput = $("#dynamicSize");
                let lastSizeSelect = $(".size-select").last(); // Get the last added color-select
                lastSizeSelect.on("change", function() {
                    let selectedSize = $(this).find("option:selected").val();
                    dynamicSizeInput.val(selectedSize);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addFlavorButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper

                $("#flavorWeightWrapper").empty();
                $("#piecesWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#shapeSizeWrapper").empty();
                $("#colorSizeWrapper").empty();



                $(flavorwrapper).append(`
                  <div class="row align-items-end">

                      <div class="col">
                          <div class="form-group">
                              <label>Flavor</label>
                              <select class="form-control form-control-custom flavor-select" name="flavor[]">
                                  <option value="" disabled selected>Select Flavor</option>
                                  <?php $__currentLoopData = $flavor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flavors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($flavors->id); ?>"><?php echo e($flavors->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicColorInput = $("#dynamicColor");
                // Get the last added color-select
                lastColorSelect.on("change", function() {
                    let selectedColor = $(this).find("option:selected").val();
                    dynamicColorInput.val(selectedColor);
                });
                // Update the dynamicColor input when a new color is selected
                let dynamicFlavorInput = $("#dynamicFlavor");
                // Get the last added flavor-select
                lastFlavorSelect.on("change", function() {
                    let selectedFlavor = $(this).find("option:selected").val();
                    dynamicFlavorInput.val(selectedFlavor);
                });

                let dynamicSizeInput = $("#dynamicSize");
                let lastSizeSelect = $(".size-select").last(); // Get the last added color-select
                lastSizeSelect.on("change", function() {
                    let selectedSize = $(this).find("option:selected").val();
                    dynamicSizeInput.val(selectedSize);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addFlavorWeightButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#piecesWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#shapeSizeWrapper").empty();
                $("#colorSizeWrapper").empty();
                $(flavorWeightwrapper).append(`
                  <div class="row align-items-end">
                      <div class="col">
                          <div class="form-group">
                              <label>Flavor</label>
                              <select class="form-control form-control-custom flavor-select" name="flavor[]">
                                  <option value="" disabled selected>Select Flavor</option>
                                  <?php $__currentLoopData = $flavor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flavors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($flavors->id); ?>"><?php echo e($flavors->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Weight</label>
                              <select class="form-control form-control-custom weight-select" name="weight[]">
                                  <option value="" disabled selected>Select Weight</option>
                                  <?php $__currentLoopData = $weight; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weights): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($weights->id); ?>"><?php echo e($weights->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicFlavorInput = $("#dynamicFlavor");
                // Get the last added flavor-select
                lastFlavorSelect.on("change", function() {
                    let selectedFlavor = $(this).find("option:selected").val();
                    dynamicFlavorInput.val(selectedFlavor);
                });

                let dynamicWeightInput = $("#dynamicWeight");
                let lastWeightSelect = $(".weight-select").last(); // Get the last added color-select
                lastWeightSelect.on("change", function() {
                    let selectedWeight = $(this).find("option:selected").val();
                    dynamicWeightInput.val(selectedWeight);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addFlavorPiecesButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#flavorWeightWrapper").empty();
                $("#piecesWrapper").empty();
                $("#shapeSizeWrapper").empty();
                $("#colorSizeWrapper").empty();

                $(flavorPiecesWrapper).append(`
                  <div class="row align-items-end">
                      <div class="col">
                          <div class="form-group">
                              <label>Flavor</label>
                              <select class="form-control form-control-custom flavor-select" name="flavor[]">
                                  <option value="" disabled selected>Select Flavor</option>
                                  <?php $__currentLoopData = $flavor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flavors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($flavors->id); ?>"><?php echo e($flavors->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Pieces</label>
                              <select class="form-control form-control-custom pieces-select" name="pieces[]">
                                  <option value="" disabled selected>Select Pieces</option>
                                  <?php $__currentLoopData = $pieces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piecess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($piecess->id); ?>"><?php echo e($piecess->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicFlavorInput = $("#dynamicFlavor");
                // Get the last added flavor-select
                lastFlavorSelect.on("change", function() {
                    let selectedFlavor = $(this).find("option:selected").val();
                    dynamicFlavorInput.val(selectedFlavor);
                });

                let dynamicPiecesInput = $("#dynamicPieces");
                let lastPiecesSelect = $(".pieces-select").last(); // Get the last added color-select
                lastPiecesSelect.on("change", function() {
                    let selectedPieces = $(this).find("option:selected").val();
                    dynamicPiecesInput.val(selectedPieces);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addShapeSizeButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#flavorWeightWrapper").empty();
                $("#piecesWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#colorSizeWrapper").empty();

                $(shapeSizeWrapper).append(`
                  <div class="row align-items-end">
                      <div class="col">
                          <div class="form-group">
                              <label>Shape</label>
                              <select class="form-control form-control-custom shape-select" name="shape[]">
                                  <option value="" disabled selected>Select Shape</option>
                                  <?php $__currentLoopData = $shape; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shapes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($shapes->id); ?>"><?php echo e($shapes->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Size</label>
                              <select class="form-control form-control-custom size-select" name="size[]">
                                  <option value="" disabled selected>Select Size</option>
                                  <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($sizes->id); ?>"><?php echo e($sizes->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicShapeInput = $("#dynamicShape");
                // Get the last added shape-select
                lastShapeSelect.on("change", function() {
                    let selectedShape = $(this).find("option:selected").val();
                    dynamicShapeInput.val(selectedShape);
                });

                let dynamicSizeInput = $("#dynamicSize");
                let lastSizeSelect = $(".size-select").last(); // Get the last added color-select
                lastSizeSelect.on("change", function() {
                    let selectedSize = $(this).find("option:selected").val();
                    dynamicSizeInput.val(selectedSize);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addPiecesButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#flavorWeightWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#shapeSizeWrapper").empty();
                $("#colorSizeWrapper").empty();
                $(piecesWrapper).append(`
                  <div class="row align-items-end">

                      <div class="col">
                          <div class="form-group">
                              <label>Pieces</label>
                              <select class="form-control form-control-custom pieces-select" name="pieces[]">
                                  <option value="" disabled selected>Select Pieces</option>
                                  <?php $__currentLoopData = $pieces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piecess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($piecess->id); ?>"><?php echo e($piecess->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicColorInput = $("#dynamicColor");
                // Get the last added color-select
                lastColorSelect.on("change", function() {
                    let selectedColor = $(this).find("option:selected").val();
                    dynamicColorInput.val(selectedColor);
                });
                // Update the dynamicColor input when a new color is selected
                let dynamicPiecesInput = $("#dynamicPieces");
                // Get the last added pieces-select
                lastPiecesSelect.on("change", function() {
                    let selectedPieces = $(this).find("option:selected").val();
                    dynamicPiecesInput.val(selectedPieces);
                });

                let dynamicSizeInput = $("#dynamicSize");
                let lastSizeSelect = $(".size-select").last(); // Get the last added color-select
                lastSizeSelect.on("change", function() {
                    let selectedSize = $(this).find("option:selected").val();
                    dynamicSizeInput.val(selectedSize);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(wrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });
            $(flavorwrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });
            $(flavorWeightwrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });
            $(flavorPiecesWrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });

            $(shapeSizeWrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });

            $(piecesWrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });




        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_side.layouts_admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\petstore\resources\views/admin_side/product.blade.php ENDPATH**/ ?>