<?php $__env->startSection("content"); ?>
      <!-- Slider -->

    <?php echo $__env->make("client.components.slider", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Our Service -->
         <section class="our-service-area">
            <div class="container">
               <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-12">
                     <div class="category-week-box text-center">
                        <div class="category-week-img">
                           <a href="<?php echo e(url($category->pagelink())); ?>"><img src="<?php echo e(asset('storage/category_images/'.$category->image)); ?>" alt="no image found"></a>
                        </div>
                        <h3 class="theme-title"><a href="#"><?php echo e($category->name); ?></a></h3>
                     </div>
                  </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         </section>
         <!-- Our Service -->
         <!-- Furry Friend -->
         <section class="furry-friend-area page-paddings">
            <div class="container">
               <div class="row">
                  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-6 col-12">
                     <div class="furry-friend-box">
                        <div class="furry-friend-img">
                           <img src="<?php echo e(asset('assets/dog.png')); ?>" alt="">
                        </div>
                        <div class="furry-friend-content">
                           <div class="furry-top-title">
                              <h3 class="theme-title">Top Reasons to Select Our Pet Shop's Products and Supplies</h3>
                              <div class="furry-line">
                                 <img src="<?php echo e(asset('furry-line.png')); ?>" alt="">
                              </div>

                           </div>
                           <p class="theme-description">Our pet shop provides quality products and supplies to meet pets' needs.
                             We carefully select each product to ensure safety, durability, and effectiveness
                             .We offer premium pet food, accessories, and grooming supplies to keep pets healthy and happy.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-6 col-lg-6 col-md-12 col-sm-6 col-12">
                     <div class="furry-friend-box">
                        <div class="furry-friend-img">
                           <img src="<?php echo e(asset('assets/cat.jpeg')); ?>" alt="">
                        </div>
                        <div class="furry-friend-content">
                           <div class="furry-top-title">
                              <h3 class="theme-title">Efficient Order Delivery Process</h3>
                              <div class="furry-line">
                                 <img src="<?php echo e(asset('furry-line.png')); ?>" alt="">
                              </div>

                           </div>
                           <p class="theme-description">The company prides itself on its efficient order delivery process,
                             which involves a rigorous process to ensure quick and accurate processing of orders.

                             The efficient order delivery process is an important part of the company's commitment to customer satisfaction.</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- Furry Friend -->
         <!-- Pet Product -->
         <section class="pet-product-area">
            <div class="container">
               <div class="row">
                  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                     <div class="page-title text-center">
                        <h2>Featured Products</h2>
                        <p>Here are listed different kinds of healthy & nutritious popular pet foods for you to choose for your beloved pet.</p>
                     </div>
                  </div>
               </div>
               <div class="row">
                   <?php $__currentLoopData = $fproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12 ps-column-width">
                     <div class="product-box <?php echo e($fproduct->quantity<1?'out-of-stock-box':''); ?> text-center">
                        <div class="product-images">
                           <a href="<?php echo e(url($fproduct->pagelink())); ?>">
                           <img src="<?php echo e(asset($fproduct->photo)); ?>" alt="">
                           </a>
                          <?php if(auth()->guard()->check()): ?>
                            <i data-id="<?php echo e($fproduct->id); ?>" class="pro-whislist-ico far fa-heart addtowish"></i>
                          <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>"  class="pro-whislist-ico far fa-heart addtowish"></a>
                          <?php endif; ?>

                        </div>
                        <div class="product-content">
                           <span><?php echo e($fproduct->category->name); ?></span>
                           <h3 class="theme-title"><a href="<?php echo e(url($fproduct->pagelink())); ?>"><?php echo e($fproduct->name); ?></a></h3>
                           <div class="product-ratting">
                             <?php for($i = 1; $i <= 5; $i++): ?> <?php if($i <=round($fproduct->ratings->avg('rating'))): ?>
                               <i class="fas fa-star ratting-active"></i>
                             <?php else: ?>
                               <i class="fas fa-star"></i>
                             <?php endif; ?>
                             <?php endfor; ?>
                           </div>
                          <div class="product-price">
                            <?php if($fproduct->discount): ?>
                              <span class="price"><del>AED : <?php echo e($fproduct->sale); ?></del></span> <!-- Original price -->
                              <?php
                                $discountedPrice = $fproduct->sale - ($fproduct->sale * ($fproduct->discount / 100));
                              ?>
                              <span class="price"><ins>AED : <?php echo e($discountedPrice); ?></ins></span> <!-- Discounted price -->
                            <?php else: ?>
                              <span class="price"><ins>AED : <?php echo e($fproduct->sale); ?></ins></span> <!-- No discount, display original price only -->
                            <?php endif; ?>
                          </div>

                          <div class="product-btn">
                            <a href="<?php echo e($fproduct->pagelink()); ?>" class="theme-btn">View Details</a>
                          </div>
                        </div>
                       <?php if($fproduct->quantity<1): ?>
                         <div class="product-out-stock">
                           <span>Out Of Stock</span>
                         </div>
                       <?php endif; ?>
                     </div>
                  </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         </section>
         <!-- Pet Product -->
         <!-- Pet Shop Shopping -->




















         <!-- Pet Shop Shopping -->
         <!-- Featured Product -->
         <section class="featured-product-area page-paddings">
            <div class="container">
               <div class="row">
                  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                     <div class="page-title text-center">
                        <h2>Featured Pets Products</h2>
                        <p>Below are the products that have something special and unique than regular ones. This is specifically made for your pet’s health & happiness.</p>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                     <ul class="nav nav-tabs pet-tab-box" role="tablist">
                       <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                           <a class="nav-link <?php echo e($pet->id==1?'active':''); ?>" data-toggle="tab" href="<?php echo e('#tabs-'.$pet->id); ?>" role="tab">
                           <img src="<?php echo e($pet->image); ?>" alt=""> <?php echo e($pet->name); ?>

                           </a>
                        </li>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                     <!-- Tab panes -->
                     <div class="tab-content">
                       <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane <?php echo e($pet->id==1?'active':''); ?>" id="<?php echo e('tabs-'.$pet->id); ?>" role="tabpanel">
                           <div class="featured-product-box">
                              <div class="row">
                                <?php $__currentLoopData = $pet->products()->with("ratings","category")->take(8)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12 ps-column-width">
                                    <div class="product-box <?php echo e($product->quantity<1?'out-of-stock-box':''); ?> text-center">
                                      <div class="product-images">
                                        <a href="<?php echo e(url($product->pagelink())); ?>">
                                          <img src="<?php echo e(asset($product->photo)); ?>" alt="">
                                        </a>

                                        <?php if(auth()->guard()->check()): ?>
                                          <i data-id="<?php echo e($product->id); ?>" class="pro-whislist-ico far fa-heart addtowish"></i>
                                        <?php else: ?>
                                          <a href="<?php echo e(route('login')); ?>"  class="pro-whislist-ico far fa-heart addtowish"></a>
                                        <?php endif; ?>

                                      </div>
                                      <div class="product-content">
                                        <span><?php echo e($product->category->name); ?></span>
                                        <h3 class="theme-title"><a href="<?php echo e(url($product->pagelink())); ?>"><?php echo e($product->name); ?></a></h3>
                                        <div class="product-ratting">
                                          <?php for($i = 1; $i <= 5; $i++): ?> <?php if($i <=round($product->ratings->avg('rating'))): ?>
                                            <i class="fas fa-star ratting-active"></i>
                                          <?php else: ?>
                                            <i class="fas fa-star"></i>
                                          <?php endif; ?>
                                          <?php endfor; ?></div>
                                        <div class="product-price">
                                          <?php if($product->discount): ?>
                                            <span class="price"><del>AED : <?php echo e($product->sale); ?></del></span> <!-- Original price -->
                                            <?php
                                              $discountedPrice = $product->sale - ($product->sale * ($product->discount / 100));
                                            ?>
                                            <span class="price"><ins>AED : <?php echo e($discountedPrice); ?></ins></span> <!-- Discounted price -->
                                          <?php else: ?>
                                            <span class="price"><ins>AED : <?php echo e($product->sale); ?></ins></span> <!-- No discount, display original price only -->
                                          <?php endif; ?>
                                        </div>
                                        <div class="product-btn">
                                          <a href="<?php echo e($product->pagelink()); ?>" class="theme-btn">View Details</a>
                                        </div>
                                        <?php if($product->quantity<1): ?>
                                          <div class="product-out-stock">
                                            <span>Out Of Stock</span>
                                          </div>
                                        <?php endif; ?>
                                      </div>
                                    </div>
                                  </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                 <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="show-more-btn text-center">
                                       <a href="<?php echo e(url($pet->pagelink())); ?>" class="theme-btn btn-light">Show More</a>
                                    </div>
                                 </div>
                              </div>

                           </div>
                        </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </div>

                  </div>
               </div>
            </div>
         </section>
         <!-- Featured Product -->
         <!-- Special Discount -->































      <?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\petstore\resources\views/welcome.blade.php ENDPATH**/ ?>