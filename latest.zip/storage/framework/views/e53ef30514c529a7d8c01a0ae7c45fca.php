<?php $__env->startSection('main-section'); ?>
    <main class="h-full overflow-y-auto">
        <div class="container grid px-6 mx-auto">
            <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                Pending Orders
            </h2>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>


            <div class="w-full overflow-hidden rounded-lg shadow-xs">
                <div class="w-full overflow-x-auto">
                    <table class="w-full whitespace-no-wrap">
                        <thead>
                            <tr
                                class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">
                                <th class="px-4 py-3 text-center">S.No</th>
                                <th class="px-4 py-3 text-center">Customer</th>
                                <th class="px-4 py-3 text-center">Total</th>
                                <th class="px-4 py-3 text-center">Status</th>
                                <th class="px-4 py-3 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800">
                            <?php $__currentLoopData = $pendingOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-gray-700 dark:text-gray-400">
                                    <td class="px-4 py-3 text-center">
                                        <div class="flex justify-center items-center text-sm w-full">
                                            <div>
                                                <p class="font-semibold">
                                                    <?php echo e(($pendingOrder->currentPage() - 1) * $pendingOrder->perPage() + $index + 1); ?>

                                                </p>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="px-4 py-3 text-sm text-center">
                                        <?php echo e($order->user->firstname); ?> - <?php echo e($order->user->lastname); ?>

                                    </td>

                                    <td class="px-4 py-3 text-center text-xs">
                                        <span
                                            class="px-2 py-1 font-semibold leading-tight text-green-700 bg-green-100 rounded-full dark:bg-green-700 dark:text-green-100">
                                            <?php echo e(number_format($order->bill)); ?> AED

                                        </span>
                                    </td>
                                    <td class="px-4 py-3 text-center text-sm">
                                        <span
                                            class="inline-block py-1 px-2 uppercase text-xs bg-red-600 text-white font-semibold rounded-full">
                                            <?php echo e($order->status == 0 ? 'Pending' : 'Completed'); ?>

                                        </span>
                                    </td>

                                    <td class="px-4 py-3 text-center">
                                        <div class="flex justify-center space-x-4 text-sm">
                                            <button
                                                class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                                                aria-label="Details">
                                                <svg class="w-5 h-5" aria-hidden="true" fill="currentColor"
                                                    viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd"
                                                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zm-1 3a1 1 0 00-1 1v3a1 1 0 102 0v-3a1 1 0 00-1-1z"
                                                        clip-rule="evenodd" />
                                                </svg>
                                            </button>

                                            <button @click="openModal"
                                                class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                                                aria-label="Delete">
                                                <svg class="w-5 h-5" aria-hidden="true" fill="currentColor"
                                                    viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd"
                                                        d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                                                        clip-rule="evenodd"></path>
                                                </svg>
                                            </button>

                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php if($pendingOrder->count() > 12): ?>
                    <div
                        class="grid px-4 py-3 text-xs font-semibold tracking-wide text-gray-500 uppercase border-t dark:border-gray-700 bg-gray-50 sm:grid-cols-9 dark:text-gray-400 dark:bg-gray-800">
                        <span class="flex items-center col-span-3">
                            Showing <?php echo e($pendingOrder->firstItem()); ?>-<?php echo e($pendingOrder->lastItem()); ?> of
                            <?php echo e($pendingOrder->total()); ?>

                        </span>
                        <span class="col-span-2"></span>
                        <!-- Pagination -->
                        <span class="flex col-span-4 mt-2 sm:mt-auto sm:justify-end">
                            <?php echo e($pendingOrder->links('vendor.pagination.tailwind')); ?>

                        </span>
                    </div>
                <?php endif; ?>

            </div>
        </div>
        <div x-show="isModalOpen" @click.away="closeModal" @keydown.escape="closeModal"
            class="fixed inset-0 z-30 flex items-end bg-black bg-opacity-50 sm:items-center sm:justify-center"
            style="display: none;">
            <div x-show="isModalOpen" @click.away="closeModal" @keydown.escape="closeModal"
                class="w-full px-6 py-4 overflow-hidden bg-white rounded-t-lg dark:bg-gray-800 sm:rounded-lg sm:m-4 sm:max-w-xl"
                role="dialog" id="modal">
                <header class="flex justify-end">
                    <button @click="closeModal" class="text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                        aria-label="close">
                        <!-- Close icon here -->
                    </button>
                </header>
                <div class="mt-4 mb-6">
                    <p class="mb-2 text-lg font-semibold text-gray-700 dark:text-gray-300">
                        Delete Order
                    </p>
                    <p class="text-sm text-gray-700 dark:text-gray-400">
                        Are you sure you want to delete this order? This action cannot be undone.
                    </p>
                </div>
                <footer class="flex justify-end px-6 py-3 bg-gray-50 dark:bg-gray-800">
                    <button @click="closeModal"
                        class="text-white border border-gray-300 hover:border-gray-500 focus:outline-none rounded-lg px-5 py-3 mr-2">
                        Cancel
                    </button>
                    <a href="<?php echo e(route('admin.orders.delete', ['id' => $order->id])); ?>"><button
                            class="bg-red-600 hover:bg-red-700 focus:outline-none rounded-lg px-5 py-3 text-white">
                            Delete
                        </button></a>
                </footer>
            </div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Check for success message
                <?php if(session('success')): ?>
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: '<?php echo e(session('success')); ?>',
                    });
                <?php endif; ?>

                // Check for error message
                <?php if(session('error')): ?>
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: '<?php echo e(session('error')); ?>',
                    });
                <?php endif; ?>
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backEnd.Layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\petstore\resources\views/backEnd/pendingOrder.blade.php ENDPATH**/ ?>