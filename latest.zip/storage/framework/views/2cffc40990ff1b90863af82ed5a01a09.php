<?php $__env->startSection('main-section'); ?>
    <?php $__env->startPush('title'); ?>
        <title>View Product - Kimbowny</title>
    <?php $__env->stopPush(); ?>
    <style>
        .btn-outline-primary:hover .fa-edit {
            color: #fff;
        }

        .btn-outline-danger:hover .fa-trash {
            color: #fff;
        }

        .custom-select:focus {
            outline: none;
            box-shadow: none;
        }

        /* Optional: If you want to hide the dropdown arrow */
        .custom-select::-ms-expand {
            display: none;
        }

        .custom-select::-webkit-scrollbar {
            display: none;
        }

        /* For browsers that do not support custom appearance */
        .custom-select {
            text-indent: 0.01px;
            /* Remove indent */
            text-overflow: '';
            /* Prevent text wrapping */
        }

        .btn-awesome {
            background-color: #007bff;
            /* Bootstrap primary color */
            border-color: #007bff;
            color: white;
        }

        .btn-awesome:hover {
            background-color: #0056b3;
            border-color: #0056b3;
            color: #fff;
            transition: background-color 0.5s, color 0.5s;
        }

        .btn-awesome i {
            margin-right: 5px;
            transition: transform 0.5s;
        }

        .btn-awesome:hover i {
            transform: scale(1.1);
        }

        /* Custom Styles */
        .form-group .row>div {
            margin-bottom: 10px;
            margin-top: 10px;
            /* Adds space between rows */
        }

        #colorSizeWrapper,
        #flavorWrapper,
        #flavorWeightWrapper,
        #flavorPiecesWrapper,
        #shapeSizeWrapper,
        #piecesWrapper {
            background-color: #f7f7f7;
            /* Light grey background */

            border-radius: 5px;
            /* Rounded corners */
            margin-top: 10px;
            /* Space between button and wrapper */
        }

        .btncustom {
            width: 100%;
            /* Make buttons take the full width of the column */
            margin-bottom: 5px;
            /* Space below buttons */
            border-radius: 25px;
        }
    </style>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><i class="fas fa-box"></i>&nbsp;View Product</h1>
                    </div>
                    <div class="col-sm-6">
                        <div class="d-flex justify-content-between align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                                <li class="breadcrumb-item active">View Product
                                </li>
                            </ol>
                            <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-info">Add Product</a>
                        </div>
                    </div>
                </div>
        </section>




        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header sticky" style="background-color: #007bff; color: #fff;">
                                <h3 class="card-title"
                                    style="font-size: 1.5em; text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.8);">Product Table
                                </h3>

                            </div>

                            <div class="card-body table-responsive p-2" style="background-color: #f8f9fa;">
                                <table id="example" class="table table-hover table-striped text-nowrap">
                                    <thead style="background-color: #007bff9a; color: #fff;">
                                        <tr>
                                            <th class="text-center">S.NO</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Qty</th>
                                            <th class="text-center">Sale</th>
                                            <th class="text-center">Feature</th>
                                            <th class="text-center">Purchase</th>
                                            <th class="text-center">Category</th>
                                            <th class="text-center">Pet</th>
                                            <th class="text-center">Discount</th>
                                            <th class="text-center">Description</th>
                                            <th class="text-center">Image</th>
                                            <th class="text-center">Show Image</th>
                                            <th class="text-center">Actions</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php if(isset($product)): ?>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $productdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-center">
                                                        <?php echo e($index + 1); ?>

                                                    </td>
                                                    <td class="text-center" style="font-family: monospace;">
                                                        <?php echo e($productdata->name); ?></td>
                                                    <td class="text-center" style="font-family: monospace;">
                                                        <?php echo e($productdata->quantity); ?></td>
                                                    <td class="text-center" style="font-family: monospace;">
                                                        <?php echo e($productdata->sale); ?></td>


                                                    <td class="text-center" style="font-family: monospace; padding: 0; ">
                                                        <div
                                                            style="display: flex; justify-content: center; align-items: center; height: 100%; width: 100%;">
                                                            <select onchange="changeFeature(this, <?php echo e($productdata->id); ?>)"
                                                                class="form-control custom-select"
                                                                style="border: none; -webkit-appearance: none; -moz-appearance: none; appearance: none; background: transparent; text-align-last: center; width: 100%;">
                                                                <option value="1"
                                                                    <?php echo e($productdata->feature == '1' ? 'selected' : ''); ?>>
                                                                    Show
                                                                </option>
                                                                <option value="0"
                                                                    <?php echo e($productdata->feature == '0' ? 'selected' : ''); ?>>
                                                                    Hide
                                                                </option>
                                                            </select>
                                                        </div>
                                                    </td>


                                                    <td class="text-center" style="font-family: monospace;">
                                                        <?php echo e($productdata->purchase); ?></td>
                                                    <td class="text-center" style="font-family: monospace;">
                                                        <?php echo e($productdata->category->name); ?></td>
                                                    <td class="text-center" style="font-family: monospace;">
                                                        <?php echo e($productdata->pet->name); ?></td>
                                                    <td class="text-center" style="font-family: monospace;">
                                                        <?php echo e($productdata->discount); ?>%</td>
                                                    <td class="text-center" style="font-family: monospace;"
                                                        data-toggle="tooltip" data-placement="top"
                                                        title="<?php echo e($productdata->description); ?>">
                                                        <?php echo e(Str::limit($productdata->description, 10)); ?>


                                                    </td>
                                                    <td class="text-center">
                                                        <?php if($productdata->photo): ?>
                                                            <?php
                                                                $imageNames = unserialize($productdata->photo);
                                                            ?>

                                                            <?php if(is_array($imageNames) && count($imageNames) > 1): ?>
                                                                <?php $__currentLoopData = $imageNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <img src="<?php echo e(asset('storage/product_images/' . $imageName)); ?>"
                                                                        alt="<?php echo e($productdata->name); ?>" width="50"
                                                                        style="border-radius: 10px; box-shadow: 0 0 5px rgba(0, 0, 0, 0.15); margin-right: 5px;">
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('storage/product_images/' . ($imageNames[0] ?? ''))); ?>"
                                                                    alt="<?php echo e($productdata->name); ?>" width="50"
                                                                    style="border-radius: 10px; box-shadow: 0 0 5px rgba(0, 0, 0, 0.15);">
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <span>No Image Available</span>
                                                        <?php endif; ?>
                                                    </td>


                                                    <td class="text-center">
                                                        <div class="btn-group">
                                                            <button class="btn btn-sm btn-awesome" data-toggle="modal"
                                                                data-target="#showImgModal<?php echo e($productdata->id); ?>">
                                                                <i class="fa fa-image" style="font-size: 1.2em;">&nbsp;Show
                                                                    Image</i>
                                                            </button>
                                                        </div>
                                                    </td>

                                                    <td class="text-center">
                                                        <div class="btn-group">
                                                            <button class="btn btn-sm btn-outline-primary"
                                                                data-toggle="modal"
                                                                data-target="#editModal<?php echo e($productdata->id); ?>">
                                                                <i class="fa fa-edit" style="font-size: 1.2em;"></i>
                                                            </button>&nbsp;&nbsp;
                                                            <button class="btn btn-sm btn-outline-danger"
                                                                data-toggle="modal"
                                                                data-target="#deleteModal<?php echo e($productdata->id); ?>">
                                                                <i class="fa fa-trash" style="font-size: 1.2em;"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <!-- Show Img Modal -->
                                                <div class="modal fade" id="showImgModal<?php echo e($productdata->id); ?>"
                                                    tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header ">
                                                                <h5 class="modal-title" id="exampleModalLabel"><i
                                                                        class="fa fa-image"></i>&nbsp;Show Image
                                                                </h5>
                                                                <button type="button" class="close"
                                                                    data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <label>Product ID: <b
                                                                        style="font-size: 22px;"><?php echo e($productdata->id); ?></b></label>
                                                                <?php if($productdata->photo): ?>
                                                                    <?php
                                                                        $imageNames = unserialize($productdata->photo);
                                                                    ?>

                                                                    <?php if(is_array($imageNames) && count($imageNames) > 1): ?>
                                                                        <?php $__currentLoopData = $imageNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <img src="<?php echo e(asset('storage/product_images/' . $imageName)); ?>"
                                                                                alt="<?php echo e($productdata->name); ?>"
                                                                                width="50"
                                                                                style="border-radius: 10px; box-shadow: 0 0 5px rgba(0, 0, 0, 0.15); margin-right: 5px;">
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php else: ?>
                                                                        <img src="<?php echo e(asset('storage/product_images/' . ($imageNames[0] ?? ''))); ?>"
                                                                            alt="<?php echo e($productdata->name); ?>" width="50"
                                                                            style="border-radius: 10px; box-shadow: 0 0 5px rgba(0, 0, 0, 0.15);">
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <span>No Image Available</span>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Close</button>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Delete Modal -->
                                                <div class="modal fade" id="deleteModal<?php echo e($productdata->id); ?>"
                                                    tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel"><i
                                                                        class="fa fa-trash"></i>&nbsp;Delete
                                                                    Product</h5>
                                                                <button type="button" class="close"
                                                                    data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure you want to delete this Product?
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Cancel</button>
                                                                <form
                                                                    action="<?php echo e(route('admin.product.del', ['id' => $productdata->id])); ?>"
                                                                    method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <button type="submit"
                                                                        class="btn btn-danger">Delete</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Edit Area Modal -->
                                                <div class="modal fade" id="editModal<?php echo e($productdata->id); ?>"
                                                    tabindex="-1" role="dialog" aria-labelledby="editAreaModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog modal-xl" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="editAreaModalLabel"><i
                                                                        class="fa fa-edit"></i>&nbsp;Edit
                                                                    Product</h5>
                                                                <button type="button" class="close"
                                                                    data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form
                                                                    action="<?php echo e(route('admin.product.edit', ['id' => $productdata->id])); ?>"
                                                                    method="POST" enctype="multipart/form-data">
                                                                    <?php echo csrf_field(); ?>

                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">

                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                        <span
                                                                                            class="input-group-text icon"><i
                                                                                                class="fas fa-pen"></i></span>
                                                                                    </div>
                                                                                    <input type="text"
                                                                                        name="productname" required
                                                                                        class="form-control <?php $__errorArgs = ['productname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                        placeholder="Product Name..."
                                                                                        value="<?php echo e($productdata->name); ?>">
                                                                                </div>
                                                                                <?php $__errorArgs = ['productname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($message); ?></span>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">

                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                        <span
                                                                                            class="input-group-text icon"><i
                                                                                                class="fas fa-cubes"></i>
                                                                                        </span>
                                                                                    </div>
                                                                                    <input type="number"
                                                                                        name="productquantity" required
                                                                                        class="form-control <?php $__errorArgs = ['productquantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                        placeholder="Product Quantity..."
                                                                                        value="<?php echo e($productdata->quantity); ?>">
                                                                                </div>
                                                                                <?php $__errorArgs = ['productquantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($message); ?></span>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">

                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                        <span
                                                                                            class="input-group-text icon"><i
                                                                                                class="fas fa-tags"></i></span>
                                                                                    </div>
                                                                                    <input type="number"
                                                                                        class="form-control"
                                                                                        id="sale" name="sale"
                                                                                        value="<?php echo e($productdata->sale); ?>"
                                                                                        required
                                                                                        placeholder="Enter Sale...">
                                                                                </div>
                                                                            </div>
                                                                            <?php $__errorArgs = ['sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span
                                                                                    class="text-danger"><?php echo e($message); ?></span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">

                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                        <span
                                                                                            class="input-group-text icon"><i
                                                                                                class="fas fa-shopping-cart"></i>

                                                                                        </span>
                                                                                    </div>
                                                                                    <input type="number"
                                                                                        class="form-control"
                                                                                        id="purchase" required
                                                                                        name="purchase"
                                                                                        placeholder="Enter Purchase..."
                                                                                        value="<?php echo e($productdata->purchase); ?>">
                                                                                </div>
                                                                            </div>
                                                                            <?php $__errorArgs = ['purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span
                                                                                    class="text-danger"><?php echo e($message); ?></span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                                        </div>


                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                        <span
                                                                                            class="input-group-text icon">
                                                                                            <i
                                                                                                class="fas fa-layer-group"></i>
                                                                                            <!-- Changed icon to 'fa-tags' for category context -->
                                                                                        </span>
                                                                                    </div>
                                                                                    <select class="form-control"
                                                                                        id="categorySelect"
                                                                                        name="category" required>
                                                                                        <option value="" disabled
                                                                                            selected>Select Category...
                                                                                        </option>
                                                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <option
                                                                                                value="<?php echo e($category->id); ?>"
                                                                                                <?php echo e($productdata->category_id == $category->id ? 'selected' : ''); ?>>
                                                                                                <?php echo e($category->name); ?>

                                                                                            </option>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span
                                                                                    class="text-danger"><?php echo e($message); ?></span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                        <span
                                                                                            class="input-group-text icon">
                                                                                            <i class="fas fa-paw"></i>
                                                                                            <!-- Changed icon to 'fa-paw' for pet context -->
                                                                                        </span>
                                                                                    </div>
                                                                                    <select class="form-control"
                                                                                        id="petSelect" name="pet"
                                                                                        required>
                                                                                        <option value="" disabled>
                                                                                            Select Pet...</option>
                                                                                        <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <option
                                                                                                value="<?php echo e($pet->id); ?>"
                                                                                                <?php echo e($productdata->pet_id == $pet->id ? 'selected' : ''); ?>>
                                                                                                <?php echo e($pet->name); ?>

                                                                                            </option>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>

                                                                                </div>
                                                                            </div>
                                                                            <?php $__errorArgs = ['pet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span
                                                                                    class="text-danger"><?php echo e($message); ?></span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                                                        </div>


                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">

                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                        <span
                                                                                            class="input-group-text icon"><i
                                                                                                class="fas fa-percentage"></i></span>
                                                                                    </div>
                                                                                    <input type="number"
                                                                                        class="form-control"
                                                                                        id="productdiscount"
                                                                                        name="productdiscount" required
                                                                                        placeholder="Enter Discount..."
                                                                                        value="<?php echo e($productdata->discount); ?>">
                                                                                </div>
                                                                            </div>
                                                                            <?php $__errorArgs = ['productdiscount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span
                                                                                    class="text-danger"><?php echo e($message); ?></span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                        <span
                                                                                            class="input-group-text icon">
                                                                                            <i class="fas fa-star"></i>
                                                                                            <!-- Changed icon to 'fa-tags' for category context -->
                                                                                        </span>
                                                                                    </div>
                                                                                    <select
                                                                                        onchange="changeFeature(this, <?php echo e($productdata->id); ?>)"
                                                                                        class="form-control custom-select"
                                                                                        style="border: none; -webkit-appearance: none; -moz-appearance: none; appearance: none; background: transparent; text-align-last: center; width: 100%;">
                                                                                        <option value="1"
                                                                                            <?php echo e($productdata->feature == '1' ? 'selected' : ''); ?>>
                                                                                            Show
                                                                                        </option>
                                                                                        <option value="0"
                                                                                            <?php echo e($productdata->feature == '0' ? 'selected' : ''); ?>>
                                                                                            Hide
                                                                                        </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                            <?php $__errorArgs = ['feature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span
                                                                                    class="text-danger"><?php echo e($message); ?></span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                                        </div>


                                                                    </div>
                                                                    <div class="form-group">

                                                                        <div class="input-group">
                                                                            <div class="input-group-prepend">
                                                                                <span class="input-group-text icon"><i
                                                                                        class="fas fa-image"></i></span>
                                                                            </div>
                                                                            <div class="custom-file">
                                                                                <input type="file"
                                                                                    class="form-control <?php $__errorArgs = ['productimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    id="image" name="productimage">
                                                                                <label class="custom-file-label"
                                                                                    for="image"><?php echo e($productdata->photo ? basename($productdata->photo) : 'Choose file'); ?></label>
                                                                            </div>
                                                                        </div>


                                                                    </div>
                                                                    <!-- Dynamic fields for color, size, Price price, and sale price selection -->
                                                                    <div class="form-group" hidden>
                                                                        <label for="dynamicColor">Color</label>
                                                                        <input type="text" id="dynamicColor"
                                                                            name="color[]" class="form-control">
                                                                    </div>

                                                                    <div class="form-group" hidden>
                                                                        <label for="dynamicSize">Size</label>
                                                                        <input type="text" id="dynamicSize"
                                                                            name="size[]" class="form-control">
                                                                    </div>
                                                                    <div class="form-group" hidden>
                                                                        <label for="dynamicWeight">Weight</label>
                                                                        <input type="text" id="dynamicWeight"
                                                                            name="weight[]" class="form-control">
                                                                    </div>
                                                                    <div class="form-group" hidden>
                                                                        <label for="dynamicFlavor">Flavor</label>
                                                                        <input type="text" id="dynamicFlavor"
                                                                            name="flavor[]" class="form-control">
                                                                    </div>
                                                                    <div class="form-group" hidden>
                                                                        <label for="dynamicShape">Shape</label>
                                                                        <input type="text" id="dynamicShape"
                                                                            name="shape[]" class="form-control">
                                                                    </div>
                                                                    <div class="form-group" hidden>
                                                                        <label for="dynamicPieces">Pieces</label>
                                                                        <input type="text" id="dynamicPieces"
                                                                            name="pieces[]" class="form-control">
                                                                    </div>

                                                                    <div class="form-group" hidden>
                                                                        <label for="purchasePrice">Purchase Price</label>
                                                                        <input type="number" id="purchasePrice"
                                                                            name="purchase[]" class="form-control">
                                                                    </div>

                                                                    <div class="form-group" hidden>
                                                                        <label for="salePrice">Sale Price</label>
                                                                        <input type="number" id="salePrice"
                                                                            name="sale[]" class="form-control">
                                                                    </div>

                                                                    <!-- Place this before the product description in your form -->
                                                                    <div class="form-group">
                                                                        <div class="row">
                                                                            <div class="col-md-2">
                                                                                <button type="button" id="addColorSize"
                                                                                    class="btn btn-info btncustom">Add
                                                                                    Color/Size</button>

                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button type="button" id="addFlavor"
                                                                                    class="btn btn-info btncustom">Add
                                                                                    Flavor</button>

                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button type="button"
                                                                                    id="addFlavorWeight"
                                                                                    class="btn btn-info btncustom">Add
                                                                                    Flavor/Weight</button>

                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button type="button"
                                                                                    id="addFlavorPieces"
                                                                                    class="btn btn-info btncustom">Add
                                                                                    Flavor/Pieces</button>

                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button type="button" id="addShapeSize"
                                                                                    class="btn btn-info btncustom">Add
                                                                                    Shape/Size</button>

                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button type="button" id="addPieces"
                                                                                    class="btn btn-info btncustom">Add
                                                                                    Pieces</button>

                                                                            </div>
                                                                        </div>
                                                                        <div id="colorSizeWrapper"></div>
                                                                        <div id="flavorWrapper"></div>
                                                                        <div id="piecesWrapper"></div>
                                                                        <div id="shapeSizeWrapper"></div>
                                                                        <div id="flavorPiecesWrapper"></div>
                                                                        <div id="flavorWeightWrapper"></div>
                                                                        <!-- Container for dynamic color and size inputs -->
                                                                    </div>
                                                                    <div class="form-group">

                                                                        <div class="input-group">

                                                                            <textarea id="description" name="productdescription" required
                                                                                class="form-control <?php $__errorArgs = ['productdescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Product Description ..."><?php echo $productdata->description; ?></textarea>


                                                                        </div>
                                                                        <?php $__errorArgs = ['productdescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>






                                                                    <!-- Add any other form fields for editing here -->
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal">Cancel</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">Save
                                                                            Changes</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>



    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {

            let wrapper = $("#colorSizeWrapper");
            let addColorSizeButton = $("#addColorSize");

            let flavorwrapper = $("#flavorWrapper");
            let addFlavorButton = $("#addFlavor");

            let flavorWeightwrapper = $("#flavorWeightWrapper");
            let addFlavorWeightButton = $("#addFlavorWeight");

            let piecesWrapper = $("#piecesWrapper");
            let addPiecesButton = $("#addPieces");

            let flavorPiecesWrapper = $("#flavorPiecesWrapper");
            let addFlavorPiecesButton = $("#addFlavorPieces");

            let shapeSizeWrapper = $("#shapeSizeWrapper");
            let addShapeSizeButton = $("#addShapeSize");
            // Function jo form fields ko add karega


            $(addColorSizeButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#flavorWeightwrapper").empty();
                $("#piecesWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#shapeSizeWrapper").empty();

                $(wrapper).append(`
                  <div class="row align-items-end">
                      <div class="col">
                          <div class="form-group">
                              <label>Color</label>
                              <select class="form-control form-control-custom color-select" name="color[]">
                                  <option value="" disabled selected>Select Color</option>
                                  <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($colors->id); ?>"><?php echo e($colors->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Size</label>
                              <select class="form-control form-control-custom size-select" name="size[]">
                                  <option value="" disabled selected>Select Size</option>
                                  <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($sizes->id); ?>"><?php echo e($sizes->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicColorInput = $("#dynamicColor");
                // Get the last added color-select
                lastColorSelect.on("change", function() {
                    let selectedColor = $(this).find("option:selected").val();
                    dynamicColorInput.val(selectedColor);
                });

                let dynamicSizeInput = $("#dynamicSize");
                let lastSizeSelect = $(".size-select").last(); // Get the last added color-select
                lastSizeSelect.on("change", function() {
                    let selectedSize = $(this).find("option:selected").val();
                    dynamicSizeInput.val(selectedSize);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addFlavorButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper

                $("#flavorWeightWrapper").empty();
                $("#piecesWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#shapeSizeWrapper").empty();
                $("#colorSizeWrapper").empty();



                $(flavorwrapper).append(`
                  <div class="row align-items-end">

                      <div class="col">
                          <div class="form-group">
                              <label>Flavor</label>
                              <select class="form-control form-control-custom flavor-select" name="flavor[]">
                                  <option value="" disabled selected>Select Flavor</option>
                                  <?php $__currentLoopData = $flavor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flavors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($flavors->id); ?>"><?php echo e($flavors->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicColorInput = $("#dynamicColor");
                // Get the last added color-select
                lastColorSelect.on("change", function() {
                    let selectedColor = $(this).find("option:selected").val();
                    dynamicColorInput.val(selectedColor);
                });
                // Update the dynamicColor input when a new color is selected
                let dynamicFlavorInput = $("#dynamicFlavor");
                // Get the last added flavor-select
                lastFlavorSelect.on("change", function() {
                    let selectedFlavor = $(this).find("option:selected").val();
                    dynamicFlavorInput.val(selectedFlavor);
                });

                let dynamicSizeInput = $("#dynamicSize");
                let lastSizeSelect = $(".size-select").last(); // Get the last added color-select
                lastSizeSelect.on("change", function() {
                    let selectedSize = $(this).find("option:selected").val();
                    dynamicSizeInput.val(selectedSize);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addFlavorWeightButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#piecesWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#shapeSizeWrapper").empty();
                $("#colorSizeWrapper").empty();
                $(flavorWeightwrapper).append(`
                  <div class="row align-items-end">
                      <div class="col">
                          <div class="form-group">
                              <label>Flavor</label>
                              <select class="form-control form-control-custom flavor-select" name="flavor[]">
                                  <option value="" disabled selected>Select Flavor</option>
                                  <?php $__currentLoopData = $flavor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flavors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($flavors->id); ?>"><?php echo e($flavors->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Weight</label>
                              <select class="form-control form-control-custom weight-select" name="weight[]">
                                  <option value="" disabled selected>Select Weight</option>
                                  <?php $__currentLoopData = $weight; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weights): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($weights->id); ?>"><?php echo e($weights->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicFlavorInput = $("#dynamicFlavor");
                // Get the last added flavor-select
                lastFlavorSelect.on("change", function() {
                    let selectedFlavor = $(this).find("option:selected").val();
                    dynamicFlavorInput.val(selectedFlavor);
                });

                let dynamicWeightInput = $("#dynamicWeight");
                let lastWeightSelect = $(".weight-select").last(); // Get the last added color-select
                lastWeightSelect.on("change", function() {
                    let selectedWeight = $(this).find("option:selected").val();
                    dynamicWeightInput.val(selectedWeight);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addFlavorPiecesButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#flavorWeightWrapper").empty();
                $("#piecesWrapper").empty();
                $("#shapeSizeWrapper").empty();
                $("#colorSizeWrapper").empty();

                $(flavorPiecesWrapper).append(`
                  <div class="row align-items-end">
                      <div class="col">
                          <div class="form-group">
                              <label>Flavor</label>
                              <select class="form-control form-control-custom flavor-select" name="flavor[]">
                                  <option value="" disabled selected>Select Flavor</option>
                                  <?php $__currentLoopData = $flavor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flavors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($flavors->id); ?>"><?php echo e($flavors->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Pieces</label>
                              <select class="form-control form-control-custom pieces-select" name="pieces[]">
                                  <option value="" disabled selected>Select Pieces</option>
                                  <?php $__currentLoopData = $pieces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piecess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($piecess->id); ?>"><?php echo e($piecess->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicFlavorInput = $("#dynamicFlavor");
                // Get the last added flavor-select
                lastFlavorSelect.on("change", function() {
                    let selectedFlavor = $(this).find("option:selected").val();
                    dynamicFlavorInput.val(selectedFlavor);
                });

                let dynamicPiecesInput = $("#dynamicPieces");
                let lastPiecesSelect = $(".pieces-select").last(); // Get the last added color-select
                lastPiecesSelect.on("change", function() {
                    let selectedPieces = $(this).find("option:selected").val();
                    dynamicPiecesInput.val(selectedPieces);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addShapeSizeButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#flavorWeightWrapper").empty();
                $("#piecesWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#colorSizeWrapper").empty();

                $(shapeSizeWrapper).append(`
                  <div class="row align-items-end">
                      <div class="col">
                          <div class="form-group">
                              <label>Shape</label>
                              <select class="form-control form-control-custom shape-select" name="shape[]">
                                  <option value="" disabled selected>Select Shape</option>
                                  <?php $__currentLoopData = $shape; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shapes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($shapes->id); ?>"><?php echo e($shapes->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Size</label>
                              <select class="form-control form-control-custom size-select" name="size[]">
                                  <option value="" disabled selected>Select Size</option>
                                  <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($sizes->id); ?>"><?php echo e($sizes->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicShapeInput = $("#dynamicShape");
                // Get the last added shape-select
                lastShapeSelect.on("change", function() {
                    let selectedShape = $(this).find("option:selected").val();
                    dynamicShapeInput.val(selectedShape);
                });

                let dynamicSizeInput = $("#dynamicSize");
                let lastSizeSelect = $(".size-select").last(); // Get the last added color-select
                lastSizeSelect.on("change", function() {
                    let selectedSize = $(this).find("option:selected").val();
                    dynamicSizeInput.val(selectedSize);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(addPiecesButton).click(function(e) {
                e.preventDefault();
                // Toggle visibility of colorSizeWrapper
                $("#flavorWrapper").empty();
                $("#flavorWeightWrapper").empty();
                $("#flavorPiecesWrapper").empty();
                $("#shapeSizeWrapper").empty();
                $("#colorSizeWrapper").empty();
                $(piecesWrapper).append(`
                  <div class="row align-items-end">

                      <div class="col">
                          <div class="form-group">
                              <label>Pieces</label>
                              <select class="form-control form-control-custom pieces-select" name="pieces[]">
                                  <option value="" disabled selected>Select Pieces</option>
                                  <?php $__currentLoopData = $pieces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piecess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($piecess->id); ?>"><?php echo e($piecess->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Purchase Price</label>
                              <input type="number" name="purchasePrice[]" class="form-control form-control-custom pprice" placeholder="Purchase Price">
                          </div>
                      </div>
                      <div class="col">
                          <div class="form-group">
                              <label>Sale Price</label>
                              <input type="number" name="salePrice[]" class="form-control form-control-custom sprice" placeholder="Sale Price">
                          </div>
                      </div>
                      <div class="col-auto">
                          <button class="btn btn-danger remove-field" type="button">&times;</button>
                      </div>
                  </div>
              `); // Add input fields

                // Update the dynamicColor input when a new color is selected
                let dynamicColorInput = $("#dynamicColor");
                // Get the last added color-select
                lastColorSelect.on("change", function() {
                    let selectedColor = $(this).find("option:selected").val();
                    dynamicColorInput.val(selectedColor);
                });
                // Update the dynamicColor input when a new color is selected
                let dynamicPiecesInput = $("#dynamicPieces");
                // Get the last added pieces-select
                lastPiecesSelect.on("change", function() {
                    let selectedPieces = $(this).find("option:selected").val();
                    dynamicPiecesInput.val(selectedPieces);
                });

                let dynamicSizeInput = $("#dynamicSize");
                let lastSizeSelect = $(".size-select").last(); // Get the last added color-select
                lastSizeSelect.on("change", function() {
                    let selectedSize = $(this).find("option:selected").val();
                    dynamicSizeInput.val(selectedSize);
                });

                let dynamicPurchaseInput = $("#purchasePrice");
                let lastpprice = $(".pprice").last(); // Get the last added pprice input
                lastpprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicPurchaseInput.val(selectedpprice);
                });

                let dynamicSaleInput = $("#salePrice");
                let lastsprice = $(".sprice").last(); // Get the last added pprice input
                lastsprice.on("input", function() {
                    let selectedpprice = $(this).val();
                    dynamicSaleInput.val(selectedpprice);
                });


            });

            $(wrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });
            $(flavorwrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });
            $(flavorWeightwrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });
            $(flavorPiecesWrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });

            $(shapeSizeWrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });

            $(piecesWrapper).on("click", ".remove-field", function(e) {
                e.preventDefault();
                $("#dynamicFlavor").val('');
                $("#dynamicPieces").val('');
                $("#dynamicColor").val('');
                $("#dynamicShape").val('');
                $("#dynamicWeight").val('');
                $("#dynamicSize").val('');
                $("#purchasePrice").val('');
                $("#salePrice").val('');
                $(this).parent().parent().remove();
            });




        });

        function changeFeature(selectElement, featureId) {
            var feature = selectElement.value;



            // Perform form submission using AJAX
            $.ajax({
                url: '<?php echo e(route('admin.product.feature.update')); ?>',
                method: 'GET',
                data: {
                    id: featureId,
                    feature: feature
                },
                success: function(response) {
                    // Assuming you're using SweetAlert2 for the Toast
                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                            toast.addEventListener('mouseenter', Swal.stopTimer)
                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    });

                    // Show success toast
                    Toast.fire({
                        icon: 'success',
                        title: response.success
                    });
                },
                error: function(xhr, status, error) {
                    // Show error toast
                    Toast.fire({
                        icon: 'error',
                        title: 'Error! Updating Product Feature'
                    });
                }
            });

        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_side.layouts_admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\petstore\resources\views/admin_side/productView.blade.php ENDPATH**/ ?>