
<?php $__env->startSection("content"); ?>

  <!-- Bradcrumb -->
  <section class="bradcrumb-area page-background">
    <div class="container">
      <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
          <div class="bradcrumb-box text-center">
            <h1>Checkout</h1>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Bradcrumb -->
  <!-- Checout -->
  <section class="checout-area page-paddings">
    <div class="container">
      <div class="row">
        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12">
          <div class="checkout-title">
            <h3 class="theme-title">Billing address</h3>
          </div>
          <div class="checkout-fom-box">
            <form id="checkoutform" action="storeOrder" method="post">
              <div class="row">
                <?php echo csrf_field(); ?>
                <div class="col-md-8">
                  <div class="theme-input-box">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo e(authfilter('email')); ?>"
                           id="checkoutemail" placeholder="you@example.com">
                    <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="theme-input-box">
                    <label for="email">First Name</label>
                    <input type="text" class="form-control" name="firstname" value="<?php echo e(authfilter('firstname')); ?>"
                           placeholder="First Name">
                    <?php $__errorArgs = ["firstname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="theme-input-box">
                    <label for="email">Last Name</label>
                    <input type="text" class="form-control" name="lastname" value="<?php echo e(authfilter('lastname')); ?>"
                           placeholder="Last Name">
                    <?php $__errorArgs = ["lastname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="theme-input-box">
                    <label for="address">Address</label>
                    <textarea class="form-control" name="address" id="address" cols="20"
                              rows="3"><?php echo e(authfilter('address')); ?></textarea>
                    <?php $__errorArgs = ["address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="theme-input-box">
                    <label for="phone">Phone</label>
                    <input type="number" class="form-control" name="phone" value="<?php echo e(authfilter('phone')); ?>"
                           placeholder="Phone">
                    <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="theme-input-box">
                    <label for="area">Area</label>
                    <input type="text" class="form-control" name="area" value="<?php echo e(authfilter('area')); ?>"
                           placeholder="Area">
                    <?php $__errorArgs = ["area"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="theme-input-box">
                    <label for="country">Country</label>
                    <select class="form-control custom-select" name="country" id="checkoutcountry">
                      <option value="">Choose..</option>
                      <?php if(auth()->user() && auth()->user()->country != null): ?>
                        <option selected><?php echo e(auth()->user()->country); ?></option>
                        <option <?php echo e(old('country') == 'United Arab Emirates' ? 'selected' : ''); ?>>United Arab Emirates
                        </option>
                        <option <?php echo e(old('country') == 'Saudi Arabia' ? 'selected' : ''); ?>>Saudi Arabia</option>
                      <?php else: ?>
                        <option <?php echo e(old('country') == 'United Arab Emirates' ? 'selected' : ''); ?>>United Arab Emirates
                        </option>
                        <option <?php echo e(old('country') == 'Saudi Arabia' ? 'selected' : ''); ?>>Saudi Arabia</option>
                      <?php endif; ?>
                    </select>

                    <?php $__errorArgs = ["country"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="theme-input-box">
                    <label for="state">City</label>
                    <select class="form-control custom-select" name="city" id="checkoutcity">
                      <option value=''>Choose...</option>
                      <?php if(auth()->user() && auth()->user()->city != null): ?>
                        <option selected><?php echo e(auth()->user()->city); ?></option>
                      <?php endif; ?>
                    </select>
                    <?php $__errorArgs = ["city"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <?php if(auth()->guard()->guest()): ?>
                  <div class="col-md-6">
                    <div class="theme-input-box">
                      <label for="password">Password</label>
                      <input type="password" class="form-control" name="pass" placeholder="Password">
                      <?php $__errorArgs = ["pass"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                <?php endif; ?>
                <div class="col-md-6">
                  <div class="theme-input-box">
                    <label for="pcode">Promo Code</label>
                    <input type="text" class="form-control" name="pcode" placeholder="Promo Code">
                    <?php $__errorArgs = ["pcode"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="theme-input-box">
                    <label for="zipcode">Zip Code</label>
                    <input type="text" class="form-control" value="<?php echo e(authfilter('zipcode')); ?>" name="zipcode" placeholder="Zip Code">
                    <?php $__errorArgs = ["zcode"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="theme-input-box">
                    <label for="order">Order Note</label>

                    <textarea class="form-control" name="ordernote" id="order" cols="20"
                              rows="3"><?php echo e(old('ordernote')); ?></textarea>
                    <?php $__errorArgs = ["ordernote"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="theme-input-box">
                    <label>Payment Methods</label><br>

                    <img src="<?php echo e(asset('stripe.png')); ?>" width="60">
                    <input type="radio" name="payment_method" value="stripe">

                    <br>
                    <img src="<?php echo e(asset('tabby.png')); ?>" width="60">
                    <input type="radio" name="payment_method" value="tabby">
                    <?php $__errorArgs = ["payment_method"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="checkout-btn">
                  <button type="submit" class="ml-3 theme-btn" <?php echo e(session('cart')?'':'disabled'); ?>>Place Order</button>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
          <div class="shopping-cart-box widget-box">
            <?php if(auth()->guard()->guest()): ?>
              <div class="faq-box mb-3 ">
                <div class="faq-box-list">
                  <a href="JavaScript:Void(0)" class="">Returning Customer? Click here..</a>
                  <div class="content" id="returning">
                    <div class="user signinBx">

                      <div class="formBx">
                        <form action="<?php echo e(route('login')); ?>" method="post">

                          <?php echo csrf_field(); ?>
                          <div class="theme-input-box">
                            <input class="form-control" type="email" name="email" placeholder="Email Address"/>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="theme-input-box">
                            <input class="form-control" type="password" name="password" placeholder="Password"/>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="theme-input-box">
                            <button class="theme-btn">Login</button>

                              <?php if(Route::has('password.request')): ?>
                          <a  href="<?php echo e(route('password.request')); ?>" style="text-decoration: none!important;background: none !important;
                          margin: 0px !important
                          ">
                                  <?php echo e(__('Forgot Your Password?')); ?>

                                </a>
                              <?php endif; ?>

                          </div>

                        </form>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            <?php endif; ?>
            <div class="widget">
              <div class="widget-category">
                <div class="blog-news-title">
                  <h2>Subtotal</h2>
                </div>
                <div class="subtotal-content">
                  <!-- <h3 class="theme-title">Grand Total: $84.00</h3>
                  <button class="theme-btn btn-light">Proceed To Checkout</button>
                  <p class="theme-description">Checkout with Multiple Addresses</p> -->
                  <div class="subtotal-content-box">
                    <ul>

                      <li class="text-danger">
                        NOTE* Shipping fee for products in Saudi Arabia is AED : 30.00 <br>
                        <hr>
                        NOTE* Shipping fee is AED : 10.00  for products in UAE which are below AED:100.00

                      </li>

                      <li style="color: #f89f44">
                        <hr>
                        You will Get 10% off if this is Your First Purchase

                      </li>
                      <hr>
                      <li><?php echo e($total); ?> items <span>AED : <span id="actualprice"><?php echo e($totalPrice); ?></span></span></li>
                      <?php if($isSaudi): ?>
                        <li>Shipping <span id="shippingcheck">AED : 30.00</span></li>
                        <?php else: ?>
                      <li>Shipping <span id="shippingcheck"><?php echo e($fee==0?'Free':"AED {$fee}"); ?></span></li>
                      <?php endif; ?>
                    </ul>
                    <ul>
                      <?php if($isSaudi): ?>
                        <li>Total (tax excl.) <span>AED : <span id="totalcheck"><?php echo e($totalPrice+30); ?></span></span></li>
                      <?php else: ?>
                      <li>Total (tax excl.) <span>AED : <span id="totalcheck"><?php echo e($totalPrice+$fee); ?></span></span></li>
                      <?php endif; ?>
                      <li>Taxes <span>AED : 0.00</span></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="coupon-code-box">
            <div class="card">
              <div class="card-body">
                <div class="slide-content">
                  <ul>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                      <div class="slider-images">
                        <a href="<?php echo e(url($product->link)); ?>"><img src="<?php echo e($product->photo); ?>" alt=""></a>
                      </div>
                      <div class="slider-content">
                        <h3 class="theme-title"><?php echo e($product->name); ?></h3>
                        <div class="product-price">
                          <?php if($product->discount): ?>
                            <span class="price"><del>AED : <?php echo e($product->sale); ?> X <?php echo e($product->quantity); ?></del></span> <!-- Original price -->
                            <?php
                              $discountedPrice = $product->sale - ($product->sale * ($product->discount / 100));
                            ?>
                            <span class="price"><ins>AED : <?php echo e($discountedPrice); ?> X <?php echo e($product->quantity); ?></ins></span> <!-- Discounted price -->
                          <?php else: ?>
                            <span class="price"><ins>AED : <?php echo e($product->sale); ?> X <?php echo e($product->quantity); ?></ins></span> <!-- No discount, display original price only -->
                          <?php endif; ?>
                        </div>
                      </div>



                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              </div>
            </div>

        </div>
      </div>
    </div>
    </div>
  </section>
  <!-- Checout -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\petstore\resources\views/client/pages/checkout.blade.php ENDPATH**/ ?>