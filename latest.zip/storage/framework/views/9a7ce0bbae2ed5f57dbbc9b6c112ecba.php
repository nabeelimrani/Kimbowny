<!-- Charts -->

</div>
</main>
</div>
</div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\petstore\resources\views/backEnd/Layouts/footer.blade.php ENDPATH**/ ?>