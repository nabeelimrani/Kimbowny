   <div class="theme-slide-box whishlist-slide">
         <div class="theme-slide-inner">
            <div class="slide-header">
               <h3 class="theme-title">Wishlist</h3>
               <span><span id="countwish"></span> Item</span>
               <i class="slide-close fas fa-times-circle"></i>
            </div>
            <div class="slide-content">
               <ul id="listwish">


               </ul>
            </div>
           <div class="slide-content-footer text-center">

             <ul>
               <li><a href="<?php echo e(url('/wishlist')); ?>" class="theme-btn">View Wishlist</a></li>

             </ul>
           </div>
         </div>
      </div>
<?php /**PATH C:\xampp\htdocs\petstore\resources\views/client/components/sideWishlist.blade.php ENDPATH**/ ?>