<?php $__env->startSection("content"); ?>

  <style>



  </style>
  <!-- Bradcrumb -->
    <section class="bradcrumb-area page-background">
      <div class="container">
        <div class="row">
          <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="bradcrumb-box text-center">
              <h1>Shop</h1>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Bradcrumb -->
    <!-- Shop Page -->
    <section class="shop-page-area page-paddings">
      <div class="container">
        <div class="row">
          <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 col-12">
            <div class="shop-sidebar">
              <div class="sidebar-widget sidebar-search">
                <h3 class="widget-title">Search</h3>
                <div class="sidebar-widget-box">

                    <div class="theme-input-box">
                      <form action="<?php echo e(route('search')); ?>" method="get">
                      <input class="form-control" type="text" name="query" placeholder="Search our store">
                      <button type="submit" class="widget-search-btn"><i class="fas fa-search"></i></button>

                      </form>
                    </div>

                </div>
              </div>
              <div class="sidebar-widget category-sub-menu">
                <h3 class="widget-title">Categories</h3>
                <div class="sidebar-widget-box">
                  <ul class="sidebar-category">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(url($category->pagelink())); ?>"><?php echo e($category->name); ?><span>(<?php echo e($category->products->count()); ?>)</span></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              </div>
              <div class="sidebar-widget product-sidebar-size">










              </div>

            </div>
          </div>
          <div class="col-xl-9 col-lg-9 col-md-8 col-sm-12 col-12">
            <div class="collection-shorting clearfix">
              <div class="short-tab">
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#sort-1" role="tab"><i class="fas fa-th"></i></a>
                  </li>

                </ul>
              </div>
              <div class="short-list">
                <div class="product-filter clearfix">
















                </div>
              </div>
            </div>
            <div class="shop-grid-box">
              <div class="tab-content">
                <div class="tab-pane active" id="sort-1" role="tabpanel">
                  <div class="shop-product-box">
                    <div class="row">
                      <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="product-box <?php echo e($product->quantity<1?'out-of-stock-box':''); ?> text-center">
                          <div class="product-images">
                            <a href="<?php echo e(url($product->pagelink())); ?>">
                              <img src="<?php echo e(asset($product->photo)); ?>" alt="">
                            </a>
                            <?php if(auth()->guard()->check()): ?>
                              <i data-id="<?php echo e($product->id); ?>" class="pro-whislist-ico far fa-heart addtowish"></i>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>"  class="pro-whislist-ico far fa-heart addtowish"></a>
                            <?php endif; ?>
                          </div>
                          <div class="product-content">
                            <span><?php echo e($product->category->name); ?></span>
                            <h3 class="theme-title"><a href="<?php echo e(url($product->pagelink())); ?>"><?php echo e($product->name); ?></a></h3>
                            <div class="product-ratting">
                              <i class="fas fa-star ratting-active"></i><i class="fas fa-star ratting-active"></i><i class="fas fa-star ratting-active"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <div class="product-price">
                              <?php if($product->discount): ?>
                                <span class="price"><del>AED : <?php echo e($product->sale); ?></del></span> <!-- Original price -->
                                <?php
                                  $discountedPrice = $product->sale - ($product->sale * ($product->discount / 100));
                                ?>
                                <span class="price"><ins>AED : <?php echo e($discountedPrice); ?></ins></span> <!-- Discounted price -->
                              <?php else: ?>
                                <span class="price"><ins>AED : <?php echo e($product->sale); ?></ins></span> <!-- No discount, display original price only -->
                              <?php endif; ?>
                            </div>
                            <div class="product-btn">
                              <button data-id="<?php echo e($product->id); ?>" class="theme-btn addToCart">Add To Cart</button>
                            </div>
                            <?php if($product->quantity<1): ?>
                              <div class="product-out-stock">
                                <span>Out Of Stock</span>
                              </div>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-md-12 my-5">

                          <h3>No Product Found</h3>

                        </div>
                      <?php endif; ?>
                      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="theme-pagination clearfix">
                          <?php if($products instanceof Illuminate\Pagination\LengthAwarePaginator || $products instanceof Illuminate\Pagination\Paginator): ?>
                            <?php if($products->hasPages()): ?>
                              <?php echo e($products->links()); ?>

                            <?php endif; ?>
                          <?php endif; ?>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>

            </div>
          </div>
        </div>
      </div>
      </div>
    </section>
    <!-- Shop Page -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\petstore\resources\views/client/pages/shop.blade.php ENDPATH**/ ?>