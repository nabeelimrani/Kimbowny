 <section class="slider-box-area">

     <div class="slider-area">
         <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
             <div class="banner-slider banner-one">
                 <div class="banner-box">
                     <div class="container">
                         <div class="row">
                             <div class="col-xl-6 col-lg-6 col-md-6 col-sm-8 col-12">
                                 <div class="banner-description-box">

                                     <div class="banner-description">
                                         <span class="wow fadeInUp center" data-wow-delay="0.2s">*Save
                                             <?php echo e($banner->discount); ?>% Off*</span>
                                         <h2 class="wow fadeInUp center" data-wow-delay="0.4s"><?php echo e($banner->title); ?></h2>

                                         <p class="wow fadeInUp center" data-wow-delay="0.8s"><?php echo $banner->description; ?>

                                         </p>
                                         <div class="slider-btn wow fadeInUp center" data-wow-delay="0.6s">
                                             <span class="wow fadeInUp center"
                                                 data-wow-delay="0.2s"><?php echo e($banner->promo_code); ?></span>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="col-xl-6 col-lg-6 col-md-6 col-sm-8 col-12">
                                 <div class="banner-slide-images wow pulse" data-wow-iteration="3"
                                     data-wow-duration="0.15">
                                     <img src="<?php echo e(asset('storage/banner_images/' . $banner->image)); ?>" alt="">
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
         <?php endif; ?>
     </div>
 </section>
<?php /**PATH C:\xampp\htdocs\petstore\resources\views/client/components/slider.blade.php ENDPATH**/ ?>