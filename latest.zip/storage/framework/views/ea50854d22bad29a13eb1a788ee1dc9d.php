<?php echo $__env->make('admin_side.layouts_admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main-section'); ?>
<?php echo $__env->make('admin_side.layouts_admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\petstore\resources\views/admin_side/layouts_admin/main.blade.php ENDPATH**/ ?>