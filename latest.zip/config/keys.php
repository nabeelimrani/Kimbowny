<?php


return [
  's_pk' => env('SP_KEY'),
  's_sk' => env('SK_SECRET'),
  't_pk' => env('TP_KEY'),
  't_sk' => env('TS_KEY'),
];
